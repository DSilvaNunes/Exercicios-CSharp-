﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SobrecargaConstrutor
{
    class Sopro : Instrumento
    {
        private string TipoSopro { get; set; }
        private string ModeloBoquilha { get; set; }
        
        public Sopro() // método construtor
        {
        }

        public Sopro(string tipoI) // método construtor
        {
            Tipo = tipoI;
        }

        public override void Entrada() // overload
        {
            base.Entrada(); // método pai

            GravaDados(); // método que obtém os dados

            gravarI(); // método que grava os dados

        }

        public override void Entrada(decimal dolar) // overload
        {
            base.Entrada(dolar); // método pai

            GravaDados(); // método que obtém os dados

            gravarI();  // método que grava os dados

        }

        public override void ListaCompleta()
        {
            base.ListaCompleta();
        }

        public override void ListaFornecedor()
        {
            base.ListaFornecedor();
        }

        public override void Consultar(string modelo)
        {
            base.Consultar(modelo);
        }

        private void gravarI()
        {
            StreamWriter gr = new StreamWriter("Instrumento.txt", true);
            gr.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},",
                Modelo, PrecoCusto, PorLucro, PrecoVenda, Tipo,
                DescForn, TipoSopro, ModeloBoquilha);
            Console.WriteLine("Instrumento Gravado!! <tecle algo>");
            Console.ReadKey();
            gr.Close();

        } // método privado que só serva para gravar os dados 

        private void GravaDados() // Método privado que obtém os dados 
        {
            Console.Write("Insira o tipo de Instrumento de Sopro: ");
            TipoSopro = Console.ReadLine();

            Console.Write("Insira tipo de boquilha: ");
            ModeloBoquilha = Console.ReadLine();
        }

    }
}
