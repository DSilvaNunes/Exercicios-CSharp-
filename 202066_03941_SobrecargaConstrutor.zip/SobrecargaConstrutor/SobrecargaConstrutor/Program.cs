﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SobrecargaConstrutor
{
    class Program
    {
        static void Main(string[] args)
        {

            int op = 0;
            string modeloInst = "";

            do
            {
                Console.Clear();
                Console.WriteLine("**** Sistema de Constrole de Instrumentos Musicais ****");
                Console.WriteLine("1. Cadastro de Instrumentos ");
                Console.WriteLine("2. Cadastro de Fornecedores ");
                Console.WriteLine("3. Lista completa de Instrumentos ");
                Console.WriteLine("4. Lista por Fornecedor ");
                Console.WriteLine("5. Lista completa de fornecedor ");
                Console.WriteLine("6. Consulta de Instrumentos ");
                Console.WriteLine("7. Sair ");

                do
                {
                    op = int.Parse(Console.ReadLine());
                } while (op < 0 || op > 7);

                if (op == 7)
                    break;

                switch (op)
                {
                    case 1:
                        Cadastros(); // todas as rotinas existentes para os cadastros
                        break;

                    case 2:
                        Fornecedor forn = new Fornecedor();
                        forn.Cadastrar();

                        break;

                    case 3:
                        Corda cor4 = new Corda();
                        cor4.ListaCompleta();
                        break;

                    case 4:
                        Corda cor5 = new Corda();
                        cor5.ListaFornecedor();
                        break;

                    case 5:
                        Fornecedor forn2 = new Fornecedor();
                        forn2.ListaTudo();
                        break;

                    case 6:
                        Console.Write("Modelo do Instrumento: ");
                        modeloInst = Console.ReadLine();
                        Corda cor6 = new Corda();
                        cor6.Consultar(modeloInst);
                        break;
                }

            } while (true);
        }

        public static void Cadastros()
        {

            string[] tipoInstrumento = new string[3];

            tipoInstrumento[0] = "Corda";
            tipoInstrumento[1] = "Percussão";
            tipoInstrumento[2] = "Sopro";

            int op = 0;
            decimal dolar = 0;
            string sn = "";

            // se o instrumento for inportado
            // enviaremos para a classe esse valor
            // através do método Entrada(decimal dolar)
            // caso contrário o método Entrada()
            // será acionado. Isso se chama sobregarga
            // ou overloading
            Console.Write("É importado?? (S/N): ");
            sn = Console.ReadLine();

            if (sn.ToUpper() == "S")
            {
                Console.Write("Digite o valor do dolar: ");
                dolar = decimal.Parse(Console.ReadLine());
            }

            Console.WriteLine("Tipo de Instrumento");

            // "for" para exibir o vetor com os 
            // tipos de instrumentos
            for (int i = 0; i < tipoInstrumento.Length; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, tipoInstrumento[i]);
            }

            do
            {
                op = int.Parse(Console.ReadLine());
            } while (op < 0 || op > 3);

            switch (op)
            {
                case 1:
                    // ao instanciar o a classe "corda"
                    // envia-se p parâmetro para o 
                    // método contrutor Corda(tipoI)
                    Corda cor = new Corda(tipoInstrumento[op - 1]);
                    if (sn.ToUpper() == "S")
                    {
                        cor.Entrada(dolar);
                    }
                    else
                    {
                        cor.Entrada();
                    }

                    break;

                case 2:
                    // ao instanciar o a classe "Percussao"
                    // envia-se p parâmetro para o 
                    // método contrutor Percussao(tipoI)
                    Percussao Perc = new Percussao(tipoInstrumento[op - 1]);
                    if (sn.ToUpper() == "S")
                    {
                        Perc.Entrada(dolar);
                    }
                    else
                    {
                        Perc.Entrada();
                    }
                    break;

                case 3:
                    // ao instanciar o a classe "Sopro"
                    // envia-se p parâmetro para o 
                    // método contrutor Sopro(tipoI)
                    Sopro sopro = new Sopro(tipoInstrumento[op - 1]);
                    if (sn.ToUpper() == "S")
                    {
                        sopro.Entrada(dolar);
                    }
                    else
                    {
                        sopro.Entrada();
                    }
                    break;
            }

        }

    }
}
