﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SobrecargaConstrutor
{
    class Fornecedor
    {
        private string NomeFor { get; set; }
        private string NomeContato { get; set; }
        private string FoneContato { get; set; }

        public void Cadastrar()
        {
            Console.Write("Nome do Fornecedor: ");
            NomeFor = Console.ReadLine();

            Console.Write("Nome do Contato: ");
            NomeContato = Console.ReadLine();

            Console.Write("Fone do Contato: ");
            FoneContato = Console.ReadLine();

            StreamWriter gr = new StreamWriter("Fornecedor.txt", true);

            gr.WriteLine("{0},{1},{2}", NomeFor, NomeContato, FoneContato);

            Console.WriteLine("Fornecedor Cadastrado <tecle algo>");
            gr.Close();
            Console.ReadKey();
        }

        public void ListaTudo()
        {
            StreamReader ler = new StreamReader("Fornecedor.txt");
            Console.WriteLine(ler.ReadToEnd());
            ler.Close();
            Console.ReadKey();
        }
        public virtual bool Consultar(string nomeFor)
        {
            string linha, linhaFor;
            bool ok = false;
            StreamReader ler = new StreamReader("Fornecedor.txt", true);

            while (!ler.EndOfStream)
            {
                linha = ler.ReadLine();
                linhaFor = linha.Substring(0, linha.IndexOf(",")).Trim();
                //Console.WriteLine(linhaFor.ToUpper());
                //Console.WriteLine(nomeFor.ToUpper().Trim());

                if (linhaFor.ToUpper() == nomeFor.ToUpper().Trim())
                {
                    Console.WriteLine(linha);
                    ok = true;
                    break;
                }
            }

            ler.Close();

            if (!ok)
            {
                Console.WriteLine("Fornecedor não encontrado <tecle algo>");
                Console.ReadKey();
            }

            return ok;
        }

    }
}
