﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SobrecargaConstrutor
{
    class Corda : Instrumento
    {
        private string InstCorda { get; set; }
        private string TipoCorda { get; set; }
        private int NumCorda { get; set; }

        public Corda() // // método construtor que não recebe nemhum parâmetro
        {
        }

        public Corda(string tipoI) // // método construtor que recebe nemhum parâmetro
        {
            Tipo = tipoI;
        }

        public override void Entrada() // overload
        {
            base.Entrada(); // método pai

            GravaDados(); // método que obtém os dados

            gravarI(); // método que grava os dados

        }

        public override void Entrada(decimal dolar) // overload
        {
            base.Entrada(dolar); // método pai

            GravaDados(); // método que obtém os dados

            gravarI(); // método que grava os dados

        }

        public override void ListaCompleta()
        {
            base.ListaCompleta();
        }

        public override void ListaFornecedor()
        {
            base.ListaFornecedor();
        }

        public override void Consultar(string modelo)
        {
            base.Consultar(modelo);
        }

        private void gravarI()
        {
            StreamWriter gr = new StreamWriter("Instrumento.txt", true);
            gr.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},",
                Modelo, PrecoCusto, PorLucro, PrecoVenda, Tipo,
                DescForn, InstCorda, TipoCorda, NumCorda);
            Console.WriteLine("Instrumento Gravado!! <tecle algo>");
            Console.ReadKey();
            gr.Close();

        } // método privado que só serva para gravar os dados 

        private void GravaDados() // Método privado que obtém os dados 
        {
            Console.Write("Insira o tipo de Instrumento: ");
            InstCorda = Console.ReadLine();

            Console.Write("Insira o tipo de Corda: ");
            TipoCorda = Console.ReadLine();

            Console.Write("Insira número de cordas: ");
            NumCorda = int.Parse(Console.ReadLine());
        }

    }
}
