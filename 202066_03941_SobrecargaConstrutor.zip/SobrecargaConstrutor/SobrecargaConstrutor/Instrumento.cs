﻿using System;
using System.IO;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SobrecargaConstrutor
{
    abstract class Instrumento
    {
        protected string Modelo { get; set; }
        protected decimal PrecoCusto { get; set; }
        protected decimal PorLucro { get; set; }
        protected decimal PrecoVenda { get; set; }
        protected string Tipo { get; set; }
        protected string DescForn { get; set; }

        // todos os métodos utilizados abaixo são 
        // métodos virtuais que serão usados pelos 
        // "filhos" com seus respectivos "overrride" (sobreposições)
        

        public virtual void Entrada()  //overload - sobrecarga
        {
            bool ok = false;
            string dForn;
            Console.Write("Insira o modelo: ");
            Modelo = Console.ReadLine();

            Console.Write("Insira o Preço de custo: ");
            PrecoCusto = decimal.Parse(Console.ReadLine());

            Console.Write("Insira % Lucro: ");
            PorLucro = decimal.Parse(Console.ReadLine());

            PrecoVenda = PrecoCusto * (1 + (PorLucro / 100));
            Console.WriteLine("Preço de Venda: {0}", PrecoVenda);

            // rotina para a procura do fornecedor 
            // nesse sistema o fornecedor já "deve"
            // estar cadastrado

            do {
                Console.Write("Nome do Fornecedor:  ");
                dForn = Console.ReadLine();
                Fornecedor forn = new Fornecedor();
                ok = forn.Consultar(dForn);
            } while (!ok);

            DescForn = dForn;
        } 

        public virtual void Entrada(decimal dolar) //overload - sobrecarga
        {
            bool ok = false;
            string dForn;

            Console.Write("Insira o modelo: ");
            Modelo = Console.ReadLine();

            Console.Write("Insira o Preço de custo: ");
            PrecoCusto = decimal.Parse(Console.ReadLine());

            Console.Write("Insira % Lucro: ");
            PorLucro = decimal.Parse(Console.ReadLine());


            PrecoVenda = PrecoCusto * (1 + (PorLucro / 100)) * dolar;
            Console.WriteLine("Preço de Venda: {0}", PrecoVenda);
            // rotina para a procura do fornecedor 
            // nesse sistema o fornecedor já "deve"
            // estar cadastrado
            do
            {
                Console.Write("Nome do Fornecedor:  ");
                dForn = Console.ReadLine();
                Fornecedor forn = new Fornecedor();
                ok = forn.Consultar(dForn);
            } while (!ok);

            DescForn = dForn;
        }

        public virtual void ListaCompleta()
        {
            StreamReader ler = new StreamReader("Instrumento.txt");
            Console.WriteLine(ler.ReadToEnd());
            Console.ReadKey();
            ler.Close();
        }

        public virtual void ListaFornecedor()
        {
            StreamReader ler = new StreamReader("Instrumento.txt");
            int contVirgula = 0, indice = 0;
            string linha, linhaInst, linhaFor;

            while (!ler.EndOfStream)
            {
                linha = ler.ReadLine(); // separa a linha toda
                linhaInst = linha.Substring(0, linha.IndexOf(",")); // separa o instrumento
                indice = 0; // essa variável captura o índice da 6° vírgula
                contVirgula = 0; // contador de vírgulas

                for (int i = 0; i < linha.Length; i++)
                {

                    if(linha.Substring(i,1) == ",")
                    {
                        contVirgula++;
                        if (contVirgula == 6) // conta até chegar à sexta vírgula
                        {
                            indice = i; //essa variável captura o índice da 6° vírgula
                            break;
                        }
                    }

                }

                linhaFor = linha.Substring(indice+1); // linha a partir da sexta vírgula
                linhaFor = linhaFor.Substring(0, linhaFor.IndexOf(",")); // da sexta à sétima vírgula 
                Console.WriteLine("{0} - {1}", linhaInst, linhaFor); // apresenta as duas variáveis

            }

            Console.ReadKey();
            ler.Close();

        }

        public virtual void Consultar(string modelo)
        {

            string linha, linhaModelo;
            bool ok = false;

            StreamReader ler = new StreamReader("Instrumento.txt");

            while (!ler.EndOfStream)
            {
                linha = ler.ReadLine();
                // linhaModelo separa o modelo do instrumento da linha completa
                linhaModelo = linha.Substring(0, linha.IndexOf(",")).Trim();

                if (linhaModelo.ToUpper() == modelo.ToUpper().Trim())
                {
                    Console.WriteLine(linha);
                    ok = true;
                }
            }

            ler.Close();
            if (!ok)
            {
                Console.WriteLine("Modelo não encontrado <tecle algo>");
            }
            Console.ReadKey();
        }
    }
}
