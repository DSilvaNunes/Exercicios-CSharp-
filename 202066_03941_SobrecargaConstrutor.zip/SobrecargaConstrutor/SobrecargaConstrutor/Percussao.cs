﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.AccessControl;

namespace SobrecargaConstrutor
{
    class Percussao : Instrumento
    {
        private string TipoPerc { get; set; }
        private string EquipPerc { get; set; }
        private string EquipRec { get; set; }

        public Percussao() // método construtor que não recebe nemhum parâmetro
        {
        }

        public Percussao(string tipoI) // método construtor // método construtor que recebe nemhum parâmetro
        {
            Tipo = tipoI;
        }

        public override void Entrada() // overload
        {
            base.Entrada(); // método pai

            GravaDados(); // método que obtém os daodos

            gravarI(); // método que grava os dados

        }

        public override void Entrada(decimal dolar) // overload
        {
            base.Entrada(dolar); // método pai

            GravaDados(); // método que obtém os dados

            gravarI(); // método que grava os dados

        }

        public override void ListaCompleta()
        {
            base.ListaCompleta();
        }

        public override void ListaFornecedor()
        {
            base.ListaFornecedor();
        }

        public override void Consultar(string modelo)
        {
            base.Consultar(modelo);
        }

        private void gravarI()
        {
            StreamWriter gr = new StreamWriter("Instrumento.txt", true);
            gr.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},",
                Modelo, PrecoCusto, PorLucro, PrecoVenda, Tipo,
                DescForn, TipoPerc, EquipPerc, EquipRec);
            Console.WriteLine("Instrumento Gravado!! <tecle algo>");
            Console.ReadKey();
            gr.Close();

        } // método privado que só serva para gravar os dados 
    
        private void GravaDados() // Método privado que obtém os dados 
        {
            Console.Write("Insira o tipo de Instrumento de percussão: ");
            TipoPerc = Console.ReadLine();

            Console.Write("Insira Equipamento de percussão: ");
            EquipPerc = Console.ReadLine();

            Console.Write("Insira tipo de pele: ");
            EquipRec = Console.ReadLine();
        }
    
    }
}
