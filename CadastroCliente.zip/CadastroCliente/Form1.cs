﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadastroCliente
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            mtbFone.Text = "(34)      -";
            dtpDataNasc.Value = new DateTime(1970, 01, 01);
        }

        private void mtbCodigo_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Cliente cli = new Cliente();
            cli.Nome = mtbNome.Text;
            cli.Endereco = txtEndereco.Text;
            cli.Fone = mtbFone.Text;
            cli.Cep = mtbCep.Text;
            cli.DataNas = dtpDataNasc.Value;
            cli.Codigo = int.Parse(mtbCodigo.Text);
            
            cli.Registrar();

            MessageBox.Show("Registro efetuado com sucesso");
            ZerarTudo();
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            bool ok = false;
            string nome = mtbNome.Text;
            Cliente cli = new Cliente();
            ok = cli.Procurar(nome);

            if (ok)
            {
                txtEndereco.Text = cli.Endereco;
                mtbFone.Text = cli.Fone;
                mtbCep.Text = cli.Cep;
                dtpDataNasc.Value = cli.DataNas;
                mtbCodigo.Text = cli.Codigo.ToString();

            }
            else
            {
                MessageBox.Show("Registro não encontrado");
                ZerarTudo();
            }
         
        }

        private void ZerarTudo()
        {

            mtbNome.Text = "";
            txtEndereco.Text = "";
            mtbFone.Text = "";
            mtbCep.Text = "";
            dtpDataNasc.Value = new DateTime(1970, 1, 1);
            mtbCodigo.Text = "0";

        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            Cliente cli = new Cliente();
            txtLista.Text = cli.Listar();
        }
    }
}
