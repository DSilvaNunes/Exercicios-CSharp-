﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadastroCliente
{
    class Cliente
    {

        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Fone { get; set; }
        public string Cep { get; set; }
        public DateTime DataNas { get; set; }
        public int Codigo { get; set; }
        public void Registrar()
        {

            StreamWriter gravar = new StreamWriter("Cliente.txt", true);

            gravar.WriteLine(Nome);
            gravar.WriteLine(Endereco);
            gravar.WriteLine(Fone);
            gravar.WriteLine(Cep);
            gravar.WriteLine(DataNas);
            gravar.WriteLine(Codigo);
            gravar.WriteLine("############");

            gravar.Close();

        }

        public bool Procurar(string nome)
        {
            bool ok = false;
            string linha;
            StreamReader ler = new StreamReader("Cliente.txt");

            while (!ler.EndOfStream)
            {
                linha = ler.ReadLine();

                if (linha.ToUpper().Trim() == nome.ToUpper().Trim())
                {
                    linha = ler.ReadLine();
                    Endereco = linha;

                    linha = ler.ReadLine();
                    Fone = linha;

                    linha = ler.ReadLine();
                    Cep = linha;
                    
                    linha = ler.ReadLine();
                    DataNas = DateTime.Parse(linha);

                    linha = ler.ReadLine();
                    Codigo = int.Parse(linha);
                    ok = true;
                    break;
                }

            }

            ler.Close();
            return ok;

        }

        public string Listar()
        {
            string linha, linhaLista = "";
            StreamReader ler = new StreamReader("Cliente.txt");

            while (!ler.EndOfStream)
            {
                linha = ler.ReadLine();

                Nome = linha;
                for (int i = 0; i < 6; i++)
                {
                    ler.ReadLine();
                }

                linhaLista = linhaLista + " | " + linha;
            }

            ler.Close();
            return linhaLista;

        }

 

    }
}
